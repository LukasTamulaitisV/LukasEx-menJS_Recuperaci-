document.addEventListener('DOMContentLoaded', main);


async function main() {
    const response = await fetch('./data/data.json');
    const json = await response.json();

    if (!localStorage.getItem('schedules')) {
        setItemsHorario(json.schedules[0].times);
    }

    if (!localStorage.getItem('playlists')) {
        setItemsMusica(json.playlists[0].songs);
    }
    schedules = getItemsHorario();
    playlists = getItemsMusica();
    inicializarEventos(schedules);
    pintarTabla(schedules, playlists);
    rellenarSelectFijo('timeSongSelect', playlists);
    //console.log(playlists[2].name);

}

function pintarTabla(schedules, playlists) {
    const tbody = document.getElementById('hourTable');
    limpiarNodos(tbody);
    //const nameMusica = schedules.songId.find(c=> c.songId) === playlists.
    schedules.forEach(function (s) {
        const tr = document.createElement('tr');
        [s.id, s.name, s.hour, s.duration + 's', s.songId ].forEach(function (dato) {
            const td = document.createElement('td');
            td.appendChild(document.createTextNode(dato));
            tr.appendChild(td);
        });

        const tdAcciones = document.createElement('td');
        [
            { texto: 'Editar', clase: 'btn-editar', color: 'btn-warning' },
            { texto: 'Borrar', clase: 'btn-borrar', color: 'btn-danger' },
        ].forEach(function (b) {
            const btn = document.createElement('button');
            btn.classList.add('btn', 'btn-sm', b.color, b.clase, 'me-1');
            btn.dataset.id = s.id;
            btn.appendChild(document.createTextNode(b.texto));
            tdAcciones.appendChild(btn);
        });
        tr.appendChild(tdAcciones);
        tbody.appendChild(tr);
    });

}


function inicializarEventos(schedules) {
    document.getElementById('timeForm').addEventListener('submit', function (e) {
        e.preventDefault();
        if (validarFormulario()) {
            guardarHorario(schedules);
        }
    });

    document.getElementById('scheduleSaveBtn').addEventListener('submit', function (e) {
        e.preventDefault();
        if (validarFormulario()) {
            guardarHorario(schedules);
        }
    });

    document.getElementById('hourTable').addEventListener('click', function (e) {
        if (e.target.classList.contains('btn-borrar')) {
            borrarHorario(parseInt(e.target.dataset.id), schedules);
        }
    });
    
}

function rellenarSelectFijo(idSelect, valores) {
    const select = document.getElementById(idSelect);
    limpiarNodos(select);

    const optDefault = document.createElement('option');
    optDefault.value = '';
    optDefault.appendChild(document.createTextNode('-- Selecciona canción --'));
    select.appendChild(optDefault);

    valores.forEach(function (v) {
        const opt = document.createElement('option');
        // Si es un string simple:
        if (typeof v === 'string') {
            opt.value = v;
            opt.appendChild(document.createTextNode(v));
        } else {
            // Si es un objeto con id y nombre:
            opt.value = v.name || v.id;
            opt.appendChild(document.createTextNode(v.name));
        }
        select.appendChild(opt);
    });
}

function guardarHorario(schedules) {
    const nuevo = {
        id: Date.now(),
        name: document.getElementById('timeName').value.trim(),
        hour: document.getElementById('timeHour').value,
        duration: document.getElementById('timeDuration').value,
        songId: document.getElementById('timeSongSelect').value,
    };
    schedules.push(nuevo);
    setItemsHorario(schedules);
    pintarTabla(schedules);
    document.getElementById('timeForm').reset();
}

function guardarCalendario(schedules) {
    const nuevo = {
        id: Date.now(),
        name: document.getElementById('timeName').value.trim(),
    };
    schedules.push(nuevo);
    setItemsHorario(schedules);
    pintarTabla(schedules);
    document.getElementById('nameSchedule').reset();
}


function borrarHorario(id, horarios) {
    if (!confirm('¿Seguro que quieres eliminar este horario?')) return;

    const nuevos = horarios.filter(h => h.id !== id);
    horarios.length = 0;
    nuevos.forEach(h => horarios.push(h));

    setItemsHorario(horarios);
    pintarTabla(horarios);
}



function validarFormulario() {
    const timeName = document.getElementById('timeName');
    const timeHour = document.getElementById('timeHour');
    const timeDuration = document.getElementById('timeDuration');

    // Paso 1: vacíos
    if (timeName.value.trim() === '' || timeHour.value.trim() === '' ||
        timeDuration.value.trim() === '') {
        mostrarError('msgError', 'Todos los campos son obligatorios.');
        return false;
    }

    if (parseFloat(timeDuration.value) <= 0) {
        mostrarError('msgError', 'El importe debe ser mayor que 0.');
        return false;
    }
    ocultarError('msgError');
    return true;
}


function getItemsHorario() {
    try {
        return JSON.parse(localStorage.getItem('schedules')) || [];
    } catch (e) {
        localStorage.removeItem('schedules');
        return [];
    }
}
function setItemsHorario(schedules) {
    localStorage.setItem('schedules', JSON.stringify(schedules));
}

function getItemsMusica() {
    try {
        return JSON.parse(localStorage.getItem('playlists')) || [];
    } catch (e) {
        localStorage.removeItem('playlists');
        return [];
    }
}
function setItemsMusica(playlists) {
    localStorage.setItem('playlists', JSON.stringify(playlists));
}



function limpiarNodos(elemento) {
    while (elemento.firstChild) {
        elemento.removeChild(elemento.firstChild);
    }
}
function mostrarError(idElemento, mensaje) {
    const p = document.getElementById(idElemento);
    limpiarNodos(p);
    p.appendChild(document.createTextNode(mensaje));
}

function ocultarError(idElemento) {
    limpiarNodos(document.getElementById(idElemento));
}